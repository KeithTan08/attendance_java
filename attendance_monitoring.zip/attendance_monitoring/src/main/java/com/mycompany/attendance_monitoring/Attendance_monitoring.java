/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.attendance_monitoring;

import java.util.ArrayList;



/**
 *
 * @author Keith Tan
 */
public class Attendance_monitoring {
    
    public static void main(String[] args) {
        HomeFrame homeFrame = new HomeFrame();
        homeFrame.setVisible(true);
    }
    
}


